# Sunday Blogger News

यह एक responsive Hindi news/blog website का starter project है।

## चलाने का तरीका
index.html को browser में खोलें।

## Hosting
पूरे folder की files hosting के public_html में upload करें।

## आगे जोड़ा जा सकता है
- Firebase/Supabase online database
- Secure Admin Login
- News Add/Edit/Delete
- Image upload
- YouTube video management
- Visitor analytics
- SEO और sitemap
