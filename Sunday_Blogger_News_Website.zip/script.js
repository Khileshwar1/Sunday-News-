const news=[
 {title:"आज की बड़ी खबर: महत्वपूर्ण समाचार अपडेट",text:"यह डेमो न्यूज़ है। Admin Panel जोड़कर यहाँ अपनी खबरें प्रकाशित की जा सकती हैं।"},
 {title:"शिक्षा और रोजगार से जुड़ी नई जानकारी",text:"परीक्षा, रिजल्ट और नौकरी से जुड़े अपडेट के लिए Sunday Blogger News देखें।"},
 {title:"देश-दुनिया की ताजा खबरों पर नजर",text:"आप अपनी पसंद की खबर, फोटो और वीडियो यहाँ आसानी से जोड़ सकते हैं।"}
];
const grid=document.getElementById("newsGrid");
grid.innerHTML=news.map((n,i)=>`<article class="card"><div class="placeholder">NEWS ${i+1}</div><div class="pad"><small>12 अगस्त 2026</small><h3>${n.title}</h3><p>${n.text}</p><a href="#about">पूरी खबर →</a></div></article>`).join("");